//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.example.sprawdzanie;

import java.util.Calendar;
import java.util.Date;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.BanList.Type;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

class SprawdzaniePlugin extends JavaPlugin {
    SprawdzaniePlugin() {
    }

    public void onEnable() {
        this.getCommand("sprawdzanie").setExecutor(new SprawdzanieCommand());
    }

    public class SprawdzanieCommand implements CommandExecutor {
        public SprawdzanieCommand() {
        }

        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (args.length != 2) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "Użycie: /sprawdzanie <gracz|czysty|cheater> <nazwa_gracza>");
                return false;
            } else {
                String action = args[0];
                String playerName = args[1];
                Player target = Bukkit.getPlayer(playerName);
                if (target == null) {
                    sender.sendMessage(String.valueOf(ChatColor.RED) + "Gracz o podanej nazwie nie jest online.");
                    return false;
                } else {
                    Location cleanLocation;
                    if (action.equalsIgnoreCase("gracz")) {
                        cleanLocation = new Location(Bukkit.getWorld("world"), 100.0, 65.0, 100.0);
                        target.teleport(cleanLocation);
                        target.sendTitle(String.valueOf(ChatColor.RED) + "JESTEŚ SPRAWDZANY", String.valueOf(ChatColor.YELLOW) + "patrz czat", 10, 70, 20);
                        sender.sendMessage(String.valueOf(ChatColor.GREEN) + "Gracz został teleportowany na miejsce sprawdzania.");
                    } else if (action.equalsIgnoreCase("czysty")) {
                        cleanLocation = new Location(Bukkit.getWorld("world"), 200.0, 70.0, 200.0);
                        target.teleport(cleanLocation);
                        target.sendMessage(String.valueOf(ChatColor.GREEN) + "Jesteś czysty!");
                        sender.sendMessage(String.valueOf(ChatColor.GREEN) + "Gracz został teleportowany na miejsce czyste.");
                    } else {
                        if (!action.equalsIgnoreCase("cheater")) {
                            sender.sendMessage(String.valueOf(ChatColor.RED) + "Nieznana akcja. Użyj: gracz, czysty lub cheater.");
                            return false;
                        }

                        Calendar calendar = Calendar.getInstance();
                        calendar.add(5, 7);
                        Date banEndDate = calendar.getTime();
                        target.kickPlayer(String.valueOf(ChatColor.RED) + "Zostałeś zbanowany za oszukiwanie na 7 dni.");
                        Bukkit.getBanList(Type.NAME).addBan(target.getName(), "Oszukiwanie", banEndDate, sender.getName());
                        sender.sendMessage(String.valueOf(ChatColor.GREEN) + "Gracz został zbanowany na 7 dni za oszukiwanie.");
                    }

                    return true;
                }
            }
        }
    }
}
